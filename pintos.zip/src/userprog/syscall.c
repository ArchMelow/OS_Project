#include "userprog/syscall.h"
#include <stdio.h>
#include <stdlib.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "lib/kernel/console.h"
#include "devices/input.h"

static void syscall_handler (struct intr_frame *);
void check_ptr (void *arg_ptr);

typedef int pid_t;

void check_ptr (void *arg_ptr) 
{
  //If the argument is not NULL and is a pointer to user virtual memory, it is valid.

  //for debugging

  //printf("PHYS_BASE : %8x, ", PHYS_BASE);
  //printf("ARG_PTR : %8x\n", arg_ptr);

  /*
  if (!arg_ptr) {
    printf("pointer NULL!!\n");
  }

  if (!is_user_vaddr(arg_ptr)) {
    printf("PHYS_BASE : %8x, ", PHYS_BASE);
    printf("ARG_PTR : %8x\n", arg_ptr);
    printf("pointer in kernel virtual memory\n");
  }
  */

  if (!arg_ptr || !is_user_vaddr(arg_ptr)) {
    //printf("ERROR : Invaild pointer given as an argument in user system call\n");
    exit(-1);
  }
} 

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  //from syscall-nr.h, we know the System Call Numbers.
  int syscall_numbers = *(int *)(f->esp);
  struct intr_frame* syscall_esp = f->esp;
  //printf("syscall_number : %d\n", syscall_numbers);
  //hex_dump(f->esp, f->esp, 100, 1);
  switch (syscall_numbers) {

    //Check the argument's validity
    //Stack while syscall is invoked : [arg[n], arg[n-1] ...... arg[0], SYS_CALL_NUMBER (*(f->esp))]
    //In every cases, we need to check if :
    // 1) The pointer address (*(f->esp) + 4) is NULL
    // 2) The pointer being passed is a pointer to unmapped virtual memory
    // 3) The pointer is a pointer to kernel virtual address space (above PHYS_BASE)
    //Checking Above conditions is what check_ptr() does.

    case SYS_HALT :
      //halt with no argument.
      halt();
      break;
    
    case SYS_EXIT :
      //exit with one argument.
      check_ptr((uint32_t *)syscall_esp + 1);
      exit(*((uint32_t *)syscall_esp + 1));
      break;
    
    case SYS_EXEC :
      check_ptr((uint32_t *)syscall_esp + 1);
      f->eax = exec(*((uint32_t *)syscall_esp + 1));
      break;
    
    case SYS_WAIT :
      break;
    
    case SYS_CREATE :
      break;
    
    case SYS_REMOVE :
      break;
    
    case SYS_OPEN :
      break;
    
    case SYS_FILESIZE :
      break;
    
    case SYS_READ :
      check_ptr((uint32_t *)syscall_esp);
      check_ptr((uint32_t *)syscall_esp + 1);
      check_ptr((uint32_t *)syscall_esp + 2);
      
      f->eax = read(*((uint32_t *)syscall_esp + 1), *((uint32_t *)syscall_esp + 2), *((uint32_t *)syscall_esp + 3));
      break;
    
    case SYS_WRITE :
      check_ptr((uint32_t *)syscall_esp);
      check_ptr((uint32_t *)syscall_esp + 1);
      check_ptr((uint32_t *)syscall_esp + 2);

      f->eax = write(*((uint32_t *)syscall_esp + 1), *((uint32_t *)syscall_esp + 2), *((uint32_t *)syscall_esp + 3));
      break;
    
    case SYS_SEEK :
      break;
    
    case SYS_TELL :
      break;
    
    case SYS_CLOSE :
      break;
  }

  //printf ("system call!\n");
  //thread_exit ();
}

void halt (void) 
{
  shutdown_power_off(); 
}

void exit (int status)
{
  printf("%s: exit(%d)\n", thread_name(), status);
  thread_exit();
}

int write (int fd, const void *buffer, unsigned size)
{
  if (fd != 1) {
    return -1;
  } 
  putbuf(buffer, size);
  return size; //returns written size
}

int read (int fd, void *buffer, unsigned size)
{
  int i;

  if (fd != 0) {
    return -1;
  }
  
  for (i = 0; (unsigned)i < size; i++) {
    if (input_getc() == '\0') {
      break;
    }
  }

  return i; //the number of bytes read from STDIN.
}

pid_t exec (const char *cmd_line) 
{
  pid_t ret_val = (pid_t)(process_execute(cmd_line));
  return ret_val;
}


